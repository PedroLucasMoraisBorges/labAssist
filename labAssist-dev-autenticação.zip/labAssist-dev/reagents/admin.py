from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Reagent)
admin.site.register(ReagentBatch)