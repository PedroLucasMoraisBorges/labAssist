from django.urls import path
from .views import *
from rest_framework_simplejwt.views import ( TokenObtainPairView, TokenRefreshView, ) 

urlpatterns = [
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('login/', Login.as_view(), name='login'),
    path('logout/', Logout.as_view(), name='logout'),
    path('cadastro/', RegisterUser.as_view(), name='register'),
    path('usuarios/', Users.as_view(), name='users'),
    path('paginaUsuario/<str:id>', ViewUserProfile.as_view(), name='user_page'),
    path('', Redirect.as_view(), name=''),
    path('perfil/', ViewUserProfile.as_view(), name='user_profile'),
    path('gerenciarUsuario/<str:id>', ManageUser.as_view(), name='manage_user')
]
